<p style="text-align:center"><b>
<br><font color='#ffff00'><b>ꕥ═══════क⊹⊱ SCRIPT PREMIUM ⊰⊹क═══════ꕥ</b></font>
<p style="text-align:center"><b>
<br><font color='red'><b>╔═════════<font color='red'> RULES !! <font color='red'>════════╗ </b></font>
<br><font color='red'><b>Max 1 Login
<br><font color='red'><b>No ddos No torrent No porn
<br><font color='red'><b>Melanggar  = Banned
<br><font color='#ffff00'><b>╚═══════════════════════╝
<p style="text-align:center"><b>
<br><font color='green'><b>╔═══════<font color='green'> ORDER 👇<font color='green'>════════╗ </b></font>
<br><font color='green'><b>Wa : wa.me/6283805609815</b></><br><font color='green'><b>Tele : t.me/MAZ_FARUK
<br><font color='#ffff00'><b>╚══════════════════════╝
<br><p style="text-align:center"><b>
<br><font color='#ffff00'><b>ꕥ═══════क⊹⊱ anggun Vpn Premium ⊰⊹क═══════ꕥ</b></font>